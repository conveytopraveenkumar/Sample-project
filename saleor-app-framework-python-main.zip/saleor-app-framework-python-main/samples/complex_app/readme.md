## Prerequisites

```
pip install SQLAlchemy
```
